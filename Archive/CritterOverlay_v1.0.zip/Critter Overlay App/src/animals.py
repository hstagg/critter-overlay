"""
animals.py — Cartoon animals for Critter Overlay App

Design principles:
  - Warm dark-brown outlines on every shape (not pure black)
  - Big expressive eyes: sclera → iris → pupil → shine
  - Rosy blush marks on cheeks
  - Big heads relative to bodies (baby-face proportions = cute)
  - Blink, walk bob, tail wag animations

Colour rule: NEVER use exactly (255, 0, 255) — that is the chroma-key background.
"""

import math
import random
import pygame

# ---------------------------------------------------------------------------
# Global style constants
# ---------------------------------------------------------------------------

OUTLINE     = (48, 32, 24)   # warm dark brown — softer than pure black
SHINE       = (255, 255, 255)
BLUSH_COL   = (252, 150, 158)
IRIS_COL    = (88, 62, 40)
PUPIL_COL   = (18, 14, 14)


# ---------------------------------------------------------------------------
# Drawing primitives
# ---------------------------------------------------------------------------

def _ow(s: int) -> int:
    """Outline width proportional to animal size."""
    return max(2, int(s * 0.030))


def _ec(surface, color, cx, cy, w, h):
    """Ellipse centred at (cx, cy)."""
    pygame.draw.ellipse(surface, color,
                        (int(cx - w / 2), int(cy - h / 2), int(w), int(h)))


def _ec_o(surface, fill, cx, cy, w, h, s):
    """Outlined ellipse."""
    ow = _ow(s)
    pygame.draw.ellipse(surface, OUTLINE,
                        (int(cx-w/2-ow), int(cy-h/2-ow), int(w+ow*2), int(h+ow*2)))
    pygame.draw.ellipse(surface, fill,
                        (int(cx-w/2), int(cy-h/2), int(w), int(h)))


def _circ(surface, color, cx, cy, r):
    pygame.draw.circle(surface, color, (int(cx), int(cy)), int(r))


def _circ_o(surface, fill, cx, cy, r, s):
    """Outlined circle."""
    ow = _ow(s)
    pygame.draw.circle(surface, OUTLINE, (int(cx), int(cy)), int(r) + ow)
    pygame.draw.circle(surface, fill,   (int(cx), int(cy)), int(r))


def _poly_o(surface, fill, points, s):
    """Outlined polygon."""
    ow = _ow(s)
    # Simple outline: draw slightly thicker in outline colour, then fill on top
    pygame.draw.polygon(surface, OUTLINE, points)
    # Shrink points toward centroid for fill
    cx = sum(p[0] for p in points) / len(points)
    cy = sum(p[1] for p in points) / len(points)
    inner = [(int(px + (cx-px)*ow*0.5/max(1,math.hypot(px-cx,py-cy))),
              int(py + (cy-py)*ow*0.5/max(1,math.hypot(px-cx,py-cy))))
             for px, py in points]
    pygame.draw.polygon(surface, fill, inner)


def _mir(cx: float, offset: float, d: int) -> int:
    """Mirror x-offset by direction (d=+1 right, d=-1 left)."""
    return int(cx + offset * d)


# ---------------------------------------------------------------------------
# Shared feature helpers
# ---------------------------------------------------------------------------

def _cute_eye(surface, cx, cy, r, blink=False):
    """Large cartoon eye with iris, pupil, and twin shines."""
    cx, cy, r = int(cx), int(cy), int(r)
    if blink:
        pygame.draw.arc(surface, OUTLINE,
                        (cx - r, cy - r // 2, r * 2, r),
                        0, math.pi, max(2, r // 2))
        return
    ow = max(1, r // 5)
    _circ(surface, OUTLINE, cx, cy, r + ow)
    _circ(surface, SHINE,   cx, cy, r)
    ir = max(2, int(r * 0.68))
    _circ(surface, IRIS_COL, cx, cy, ir)
    pr = max(1, int(r * 0.42))
    _circ(surface, PUPIL_COL, cx, cy, pr)
    # Main shine
    _circ(surface, SHINE, cx + max(1, int(r*0.28)), cy - max(1, int(r*0.30)), max(1, int(r*0.28)))
    # Soft secondary shine
    _circ(surface, (210, 210, 210), cx - max(1, int(r*0.18)), cy + max(1, int(r*0.18)), max(1, int(r*0.13)))


def _blush(surface, cx, cy, s):
    """Rosy cheek oval."""
    _ec(surface, BLUSH_COL, cx, cy, int(s * 0.14), int(s * 0.08))


def _whiskers(surface, cx, cy, s, d):
    """Three whisker lines each side of nose."""
    wl = int(s * 0.20)
    for i in range(3):
        wy = int(cy) + int((i - 1) * s * 0.045)
        dy = int((i - 1) * s * 0.015)
        pygame.draw.line(surface, OUTLINE,
                         (_mir(cx,  s*0.06, d), wy),
                         (_mir(cx,  s*0.06+wl, d), wy + dy), 1)
        pygame.draw.line(surface, OUTLINE,
                         (_mir(cx, -s*0.06, d), wy),
                         (_mir(cx, -s*0.06-int(wl*0.75), d), wy + dy), 1)


# ---------------------------------------------------------------------------
# Particle — pop effect
# ---------------------------------------------------------------------------

class Particle:
    GRAVITY = 380

    def __init__(self, x, y, color):
        self.x, self.y = float(x), float(y)
        self.color = color
        angle = random.uniform(0, 2 * math.pi)
        speed = random.uniform(90, 230)
        self.vx = math.cos(angle) * speed
        self.vy = math.sin(angle) * speed - random.uniform(40, 110)
        self.radius = random.randint(4, 9)
        self.life = 1.0

    def update(self, dt):
        self.vy += self.GRAVITY * dt
        self.x  += self.vx * dt
        self.y  += self.vy * dt
        self.life -= dt * 3.0
        return self.life > 0

    def draw(self, surface):
        r = max(1, int(self.radius * self.life))
        _circ(surface, self.color, self.x, self.y, r)


# ---------------------------------------------------------------------------
# Base Animal class
# ---------------------------------------------------------------------------

class Animal:
    SPECIES        = "animal"
    BASE_SPEED     = 45
    SPEED_VARIANCE = 0.25
    SIZE_SCALE     = 1.0
    PARTICLE_COLORS = [(200, 200, 200)]

    WALKING = "walking"
    IDLE    = "idle"
    TURNING = "turning"
    POPPING = "popping"

    def __init__(self, x, y, size, screen_w, screen_h,
                 direction=None, perimeter_walker=False):
        self.x, self.y = float(x), float(y)
        self.size = max(60, int(size * self.SIZE_SCALE))
        self.screen_w, self.screen_h = screen_w, screen_h
        self.perimeter_walker = perimeter_walker
        self.direction = direction if direction is not None else random.choice([-1, 1])
        self.vert_dir  = random.choice([-1, 1])

        spd = self.BASE_SPEED * (1 + random.uniform(-self.SPEED_VARIANCE, self.SPEED_VARIANCE))
        ang = random.uniform(-20, 20) * math.pi / 180
        self.vx = spd * self.direction * math.cos(ang)
        self.vy = spd * self.vert_dir  * abs(math.sin(ang))

        self.state          = self.WALKING
        self.anim_t         = 0.0
        self.walk_phase     = 0.0
        self.blink_offset   = random.uniform(0, math.pi * 2)
        self.idle_timer     = 0.0
        self.turn_timer     = 0.0
        self.peri_segment   = 0
        self.peri_progress  = 0.0
        self.alive          = True
        self.hit_radius     = int(self.size * 0.46)

    # ------------------------------------------------------------------ update

    def update(self, dt, all_animals):
        self.anim_t     += dt
        self.walk_phase += dt * (abs(self.vx) + abs(self.vy)) * 0.055

        if self.state == self.TURNING:
            self.turn_timer -= dt
            if self.turn_timer <= 0:
                self.state = self.WALKING
        elif self.state == self.IDLE:
            self.idle_timer -= dt
            if self.idle_timer <= 0:
                self.state = self.WALKING
        elif self.state == self.WALKING:
            if self.perimeter_walker:
                self._update_perimeter(dt)
            else:
                self._update_free(dt, all_animals)
            if random.random() < dt * 0.018:
                self.state = self.IDLE
                self.idle_timer = random.uniform(0.8, 2.5)

    def _update_free(self, dt, all_animals):
        nx = self.x + self.vx * dt
        ny = self.y + self.vy * dt
        m  = self.size // 2
        bounced = False

        if nx < m:
            nx = float(m); self.vx = abs(self.vx); self.direction =  1; bounced = True
        elif nx > self.screen_w - m:
            nx = float(self.screen_w - m); self.vx = -abs(self.vx); self.direction = -1; bounced = True
        if ny < m:
            ny = float(m); self.vy = abs(self.vy); bounced = True
        elif ny > self.screen_h - m:
            ny = float(self.screen_h - m); self.vy = -abs(self.vy); bounced = True

        if bounced:
            self.state = self.TURNING
            self.turn_timer = random.uniform(0.15, 0.35)

        for other in all_animals:
            if other is self or not other.alive:
                continue
            dx, dy = self.x - other.x, self.y - other.y
            dist = math.hypot(dx, dy)
            md = (self.hit_radius + other.hit_radius) * 0.88
            if 0 < dist < md:
                nx += (dx/dist) * (md-dist) * 0.5
                ny += (dy/dist) * (md-dist) * 0.5
                self.vx += (dx/dist) * 12
                self.vy += (dy/dist) * 12
                spd = math.hypot(self.vx, self.vy)
                if spd > 0:
                    self.vx = self.vx/spd * self.BASE_SPEED
                    self.vy = self.vy/spd * self.BASE_SPEED

        self.x, self.y = nx, ny

    def _update_perimeter(self, dt):
        m, spd = self.size // 2 + 20, abs(self.BASE_SPEED) * 0.75
        segs = [
            (m, m, self.screen_w-m, m),
            (self.screen_w-m, m, self.screen_w-m, self.screen_h-m),
            (self.screen_w-m, self.screen_h-m, m, self.screen_h-m),
            (m, self.screen_h-m, m, m),
        ]
        sx, sy, ex, ey = segs[self.peri_segment]
        seg_len = math.hypot(ex-sx, ey-sy)
        self.peri_progress += spd * dt / max(seg_len, 1)
        if self.peri_progress >= 1.0:
            self.peri_progress = 0.0
            self.peri_segment  = (self.peri_segment + 1) % 4
            self.state = self.IDLE
            self.idle_timer = random.uniform(0.4, 1.2)
            sx, sy, ex, ey = segs[self.peri_segment]
        t = self.peri_progress
        self.x = sx + (ex-sx)*t
        self.y = sy + (ey-sy)*t
        if ex > sx: self.direction =  1
        elif ex < sx: self.direction = -1

    # ------------------------------------------------------------------ shared helpers

    def hit_test(self, mx, my):
        return math.hypot(self.x-mx, self.y-my) <= self.hit_radius

    def _blink(self):
        return math.sin(self.anim_t * 0.85 + self.blink_offset) > 0.96

    def _bob(self):
        if self.state == self.WALKING:
            return math.sin(self.walk_phase * 2) * self.size * 0.04
        return 0.0

    def draw(self, surface, anim_t):
        raise NotImplementedError


# ===========================================================================
# KITTEN  🐱
# ===========================================================================

class Kitten(Animal):
    SPECIES    = "kitten"
    BASE_SPEED = 52
    SIZE_SCALE = 1.0
    PARTICLE_COLORS = [(230, 165, 105), (245, 190, 130), (255, 160, 160)]

    # colour palette
    C_BODY   = (228, 168, 105)
    C_HEAD   = (240, 182, 120)
    C_EAR    = (205, 135, 82)
    C_INNER  = (255, 195, 195)
    C_STRIPE = (205, 148, 85)
    C_NOSE   = (255, 140, 148)

    def draw(self, surface, anim_t):
        x, y, s, d = int(self.x), int(self.y), self.size, self.direction
        bob = int(self._bob())
        blink = self._blink()

        # --- tail (behind body, draw first) ---
        tb = math.sin(self.anim_t * 2.2) * s * 0.14
        tail_pts = []
        for i in range(10):
            f = i / 9
            tx = _mir(x, -s*0.22 - s*0.35*f, d)
            ty = y + bob + int(s*0.10*f - s*0.20*(1-f)*f*2 + tb*f)
            tail_pts.append((tx, ty))
        if len(tail_pts) > 1:
            pygame.draw.lines(surface, self.C_STRIPE, False, tail_pts, max(4, int(s*0.09)))
            pygame.draw.lines(surface, self.C_EAR,   False, tail_pts, max(2, int(s*0.045)))

        # --- body ---
        bw, bh = int(s*0.66), int(s*0.52)
        _ec_o(surface, self.C_BODY, x, y+bob, bw, bh, s)

        # --- head (big — baby-face proportions) ---
        hx = _mir(x, s*0.22, d)
        hy = y - int(s*0.26) + bob
        hr = int(s*0.32)
        _circ_o(surface, self.C_HEAD, hx, hy, hr, s)

        # --- ears ---
        for side, ox, tip_ox in [(-1, -0.18, -0.28), (1, 0.10, 0.22)]:
            ex0 = hx + int(d * side * s * abs(ox))
            ey0 = hy - hr + 6
            ex1 = hx + int(d * side * s * abs(tip_ox))
            ey1 = hy - hr - int(s*0.20)
            ex2 = hx + int(d * side * s * (abs(ox)+0.12))
            ey2 = hy - hr - int(s*0.06)
            _poly_o(surface, self.C_EAR, [(ex0,ey0),(ex1,ey1),(ex2,ey2)], s)
            # inner ear
            ix0 = ex0 + int((ex1-ex0)*0.25)
            iy0 = ey0 + int((ey1-ey0)*0.25)
            ix1 = ex1
            iy1 = ey1 + int(s*0.04)
            ix2 = ex2 + int((ex1-ex2)*0.22)
            iy2 = ey2 + int((ey1-ey2)*0.22)
            pygame.draw.polygon(surface, self.C_INNER, [(ix0,iy0),(ix1,iy1),(ix2,iy2)])

        # --- forehead stripes ---
        for i in range(3):
            sy2 = hy - hr + int(s*(0.05 + i*0.07))
            pygame.draw.line(surface, self.C_STRIPE,
                             (hx - int(s*0.08), sy2), (hx + int(s*0.08), sy2),
                             max(1, int(s*0.025)))

        # --- eyes ---
        er = max(5, int(s * 0.13))
        for ox in [-0.11, 0.11]:
            ex = hx + int(s * ox * d)
            _cute_eye(surface, ex, hy - int(s*0.04), er, blink)

        # --- blush ---
        _blush(surface, hx + int(d * -s*0.16), hy + int(s*0.06), s)
        _blush(surface, hx + int(d *  s*0.16), hy + int(s*0.06), s)

        # --- nose ---
        nx2, ny2 = hx, hy + int(s*0.10)
        npts = [(nx2, ny2-int(s*0.04)),
                (nx2-int(s*0.04), ny2+int(s*0.03)),
                (nx2+int(s*0.04), ny2+int(s*0.03))]
        pygame.draw.polygon(surface, self.C_NOSE, npts)

        # --- mouth ---
        pygame.draw.arc(surface, OUTLINE,
                        (hx-int(s*0.07), hy+int(s*0.10), int(s*0.07), int(s*0.07)),
                        math.pi, 2*math.pi, max(1, int(s*0.025)))
        pygame.draw.arc(surface, OUTLINE,
                        (hx, hy+int(s*0.10), int(s*0.07), int(s*0.07)),
                        math.pi, 2*math.pi, max(1, int(s*0.025)))

        # --- whiskers ---
        _whiskers(surface, hx, hy+int(s*0.09), s, d)

        # --- legs ---
        lw, lh = int(s*0.14), int(s*0.15)
        sw2 = math.sin(self.walk_phase*2) * int(s*0.04) if self.state==self.WALKING else 0
        for i, ox in enumerate([-0.28, -0.09, 0.09, 0.28]):
            lb = sw2 if i%2==0 else -sw2
            _ec_o(surface, self.C_EAR, x+int(s*ox), y+int(bh*0.52)+lb+bob, lw, lh, s)


# ===========================================================================
# TURTLE  🐢
# ===========================================================================

class Turtle(Animal):
    SPECIES    = "turtle"
    BASE_SPEED = 28
    SIZE_SCALE = 0.95
    PARTICLE_COLORS = [(75, 148, 75), (100, 175, 90), (180, 220, 100)]

    C_SHELL  = (78, 148, 72)
    C_LIGHT  = (108, 182, 95)
    C_DOME   = (138, 205, 118)
    C_SKIN   = (108, 175, 95)
    C_BELLY  = (185, 218, 125)
    C_LINE   = (55, 108, 52)

    def draw(self, surface, anim_t):
        x, y, s, d = int(self.x), int(self.y), self.size, self.direction
        bob = int(self._bob() * 0.5)
        blink = self._blink()

        # --- shell ---
        sw, sh = int(s*0.74), int(s*0.58)
        _ec_o(surface, self.C_SHELL, x, y+bob, sw, sh, s)
        # dome highlight
        _ec(surface, self.C_LIGHT, x-int(sw*0.06), y+bob-int(sh*0.08), int(sw*0.62), int(sh*0.52))
        _ec(surface, self.C_DOME,  x-int(sw*0.10), y+bob-int(sh*0.14), int(sw*0.35), int(sh*0.30))

        # hex pattern
        for cx2, cy2, pr in [
            (x, y+bob-int(s*0.12), int(s*0.10)),
            (x-int(s*0.16), y+bob+int(s*0.04), int(s*0.09)),
            (x+int(s*0.16), y+bob+int(s*0.04), int(s*0.09)),
            (x-int(s*0.08), y+bob+int(s*0.16), int(s*0.08)),
            (x+int(s*0.08), y+bob+int(s*0.16), int(s*0.08)),
        ]:
            pygame.draw.circle(surface, self.C_LINE, (cx2, cy2), pr, max(1, int(s*0.025)))

        # --- belly plate ---
        _ec(surface, self.C_BELLY, x, y+bob+int(sh*0.28), int(sw*0.55), int(sh*0.30))

        # --- head (big and round, peeking forward) ---
        hx = _mir(x, s*0.36, d)
        hy = y - int(s*0.06) + bob
        hr = int(s*0.20)
        _circ_o(surface, self.C_SKIN, hx, hy, hr, s)

        # --- neck ---
        pygame.draw.line(surface, self.C_SKIN,
                         (_mir(x, s*0.28, d), y+bob-int(sh*0.12)),
                         (hx, hy+hr-2), max(4, int(s*0.12)))

        # --- eye ---
        er = max(4, int(s*0.10))
        _cute_eye(surface, hx+int(d*s*0.04), hy-int(s*0.04), er, blink)

        # --- mouth smile ---
        pygame.draw.arc(surface, OUTLINE,
                        (_mir(hx, -s*0.05, d), hy+int(s*0.04),
                         int(s*0.10), int(s*0.07)),
                        math.pi, 2*math.pi, max(1, int(s*0.025)))

        # --- legs ---
        leg_positions = [
            (_mir(x,  s*0.28, d), y+bob+int(sh*0.35)),
            (_mir(x,  s*0.10, d), y+bob+int(sh*0.46)),
            (_mir(x, -s*0.10, d), y+bob+int(sh*0.46)),
            (_mir(x, -s*0.28, d), y+bob+int(sh*0.35)),
        ]
        sw2 = math.sin(self.walk_phase*2)*int(s*0.035) if self.state==self.WALKING else 0
        for i,(lx,ly) in enumerate(leg_positions):
            lb = sw2 if i%2==0 else -sw2
            _ec_o(surface, self.C_SKIN, lx, ly+lb, int(s*0.16), int(s*0.12), s)


# ===========================================================================
# DUCK  🦆
# ===========================================================================

class Duck(Animal):
    SPECIES    = "duck"
    BASE_SPEED = 46
    PARTICLE_COLORS = [(248, 230, 80), (255, 200, 50), (240, 245, 220)]

    C_BODY  = (248, 245, 228)
    C_WING  = (228, 224, 205)
    C_HEAD  = (248, 218, 58)
    C_BEAK  = (228, 128, 38)
    C_FOOT  = (215, 115, 32)

    def draw(self, surface, anim_t):
        x, y, s, d = int(self.x), int(self.y), self.size, self.direction
        bob = int(self._bob())
        blink = self._blink()

        # --- body (very round and fluffy) ---
        bw, bh = int(s*0.72), int(s*0.60)
        _ec_o(surface, self.C_BODY, x, y+bob, bw, bh, s)

        # --- wing detail ---
        wx = _mir(x, -s*0.06, d)
        _ec_o(surface, self.C_WING, wx, y+bob+int(s*0.06), int(s*0.44), int(s*0.32), s)
        # feather lines
        for i in range(3):
            fy = y+bob+int(s*0.01)+i*int(s*0.06)
            pygame.draw.arc(surface, OUTLINE,
                            (wx-int(s*0.18), fy, int(s*0.36), int(s*0.06)),
                            math.pi, 2*math.pi, max(1, int(s*0.020)))

        # --- tail feathers ---
        tx = _mir(x, -s*0.35, d)
        tpts = [(tx,y+bob),(tx-int(d*s*0.20),y+bob-int(s*0.22)),(tx-int(d*s*0.08),y+bob-int(s*0.08))]
        _poly_o(surface, self.C_WING, tpts, s)

        # --- head (big round ball) ---
        hx = _mir(x, s*0.26, d)
        hy = y - int(s*0.30) + bob
        hr = int(s*0.26)
        _circ_o(surface, self.C_HEAD, hx, hy, hr, s)

        # --- beak ---
        bk_pts = [
            (hx + int(d*s*0.16), hy - int(s*0.04)),
            (hx + int(d*s*0.16), hy + int(s*0.06)),
            (hx + int(d*s*0.36), hy + int(s*0.01)),
        ]
        _poly_o(surface, self.C_BEAK, bk_pts, s)

        # --- eye ---
        er = max(5, int(s*0.12))
        _cute_eye(surface, hx - int(d*s*0.06), hy - int(s*0.04), er, blink)

        # --- blush ---
        _blush(surface, hx - int(d*s*0.14), hy + int(s*0.08), s)

        # --- feet ---
        sw2 = math.sin(self.walk_phase*2)*int(s*0.04) if self.state==self.WALKING else 0
        for i, ox in enumerate([-0.14, 0.14]):
            lb = sw2 if i==0 else -sw2
            _ec_o(surface, self.C_FOOT, x+int(s*ox), y+int(bh*0.52)+lb+bob, int(s*0.18), int(s*0.09), s)


# ===========================================================================
# RABBIT  🐰
# ===========================================================================

class Rabbit(Animal):
    SPECIES    = "rabbit"
    BASE_SPEED = 62
    SPEED_VARIANCE = 0.30
    PARTICLE_COLORS = [(205, 198, 212), (242, 180, 185), (250, 248, 252)]

    C_BODY  = (205, 198, 215)
    C_HEAD  = (220, 215, 228)
    C_EAR   = (218, 212, 226)
    C_INNER = (242, 175, 182)
    C_NOSE  = (255, 148, 158)
    C_TAIL  = (250, 250, 254)

    def draw(self, surface, anim_t):
        x, y, s, d = int(self.x), int(self.y), self.size, self.direction
        bob = int(self._bob())
        hop = abs(math.sin(self.walk_phase*2)) * int(s*0.05) if self.state==self.WALKING else 0
        blink = self._blink()

        # --- tail ---
        tx = _mir(x, -s*0.34, d)
        _circ_o(surface, self.C_TAIL, tx, y+int(s*0.12)+bob, int(s*0.14), s)

        # --- body (fluffy oval) ---
        bw, bh = int(s*0.62), int(s*0.58)
        _ec_o(surface, self.C_BODY, x, y+bob, bw, bh, s)

        # --- head (big) ---
        hx = _mir(x, s*0.18, d)
        hy = y - int(s*0.28) + bob - hop
        hr = int(s*0.30)
        _circ_o(surface, self.C_HEAD, hx, hy, hr, s)

        # --- ears ---
        ear_h, ear_w = int(s*0.58), int(s*0.13)
        tilt = math.sin(self.walk_phase*2)*int(s*0.04) if self.state==self.WALKING else 0
        for i, ox in enumerate([-0.11, 0.11]):
            ecx = hx + int(s * ox * d)
            ecy = hy - hr - ear_h//2
            tilt2 = tilt if i==0 else -tilt
            _ec_o(surface, self.C_EAR, ecx+tilt2, ecy, ear_w, ear_h, s)
            _ec(surface, self.C_INNER, ecx+tilt2, ecy+int(ear_h*0.08), int(ear_w*0.52), int(ear_h*0.72))

        # --- eyes ---
        er = max(6, int(s*0.13))
        for ox in [-0.10, 0.10]:
            _cute_eye(surface, hx+int(s*ox*d), hy-int(s*0.04), er, blink)

        # --- blush ---
        _blush(surface, hx+int(d*-s*0.18), hy+int(s*0.07), s)
        _blush(surface, hx+int(d* s*0.18), hy+int(s*0.07), s)

        # --- nose ---
        _circ_o(surface, self.C_NOSE, hx, hy+int(s*0.10), max(3, int(s*0.05)), s)

        # --- mouth ---
        pygame.draw.line(surface, OUTLINE, (hx, hy+int(s*0.13)), (hx, hy+int(s*0.18)), max(1, int(s*0.025)))
        pygame.draw.arc(surface, OUTLINE,
                        (hx-int(s*0.09), hy+int(s*0.16), int(s*0.09), int(s*0.07)),
                        math.pi, 2*math.pi, max(1, int(s*0.025)))
        pygame.draw.arc(surface, OUTLINE,
                        (hx, hy+int(s*0.16), int(s*0.09), int(s*0.07)),
                        math.pi, 2*math.pi, max(1, int(s*0.025)))

        # --- whiskers ---
        _whiskers(surface, hx, hy+int(s*0.10), s, d)

        # --- feet ---
        lw, lh = int(s*0.16), int(s*0.14)
        for i, ox in enumerate([-0.20, 0.20]):
            lb = hop if i%2==0 else -hop//2
            _ec_o(surface, self.C_BODY, x+int(s*ox), y+int(bh*0.50)-lb+bob, lw, lh, s)


# ===========================================================================
# HEDGEHOG  🦔
# ===========================================================================

class Hedgehog(Animal):
    SPECIES    = "hedgehog"
    BASE_SPEED = 38
    SIZE_SCALE = 0.92
    PARTICLE_COLORS = [(135, 92, 60), (205, 165, 122), (245, 220, 180)]

    C_BACK  = (135, 92, 60)
    C_BELLY = (205, 162, 118)
    C_FACE  = (218, 180, 138)
    C_SPIKE = (112, 75, 45)
    C_NOSE  = (88, 55, 42)

    def draw(self, surface, anim_t):
        x, y, s, d = int(self.x), int(self.y), self.size, self.direction
        bob = int(self._bob() * 0.55)
        blink = self._blink()

        # --- spine body ---
        scx = _mir(x, -s*0.04, d)
        sw, sh = int(s*0.70), int(s*0.52)
        _ec_o(surface, self.C_BACK, scx, y+bob, sw, sh, s)

        # --- spikes (upper half of body only) ---
        n = 12
        for i in range(n):
            frac = i/(n-1) - 0.5
            # Arc from upper-back (≈202°) over the top (270°) to upper-front (≈338°)
            # sin is negative in this range → spikes point upward in screen coords
            base_angle = math.pi * (1.50 + frac * 0.75)
            ang = base_angle if d==1 else math.pi - base_angle
            spike_len = int(s * 0.18)
            cos_a, sin_a = math.cos(ang), math.sin(ang)
            bx = scx + int(cos_a * sw*0.44)
            by = y+bob + int(sin_a * sh*0.44)
            ex2 = bx + int(cos_a * spike_len)
            ey2 = by + int(sin_a * spike_len)
            pygame.draw.line(surface, self.C_SPIKE, (bx, by), (ex2, ey2), max(2, int(s*0.038)))
            # lighter tip
            mid_x = bx + int(cos_a * spike_len * 0.65)
            mid_y = by + int(sin_a * spike_len * 0.65)
            pygame.draw.line(surface, self.C_BACK, (mid_x, mid_y), (ex2, ey2), max(1, int(s*0.022)))

        # --- belly / face area ---
        fcx = _mir(x, s*0.14, d)
        _ec_o(surface, self.C_BELLY, fcx, y+bob, int(s*0.55), int(s*0.44), s)

        # --- snout ---
        snx = _mir(fcx, s*0.22, d)
        _ec_o(surface, self.C_FACE, snx, y+bob+int(s*0.04), int(s*0.22), int(s*0.20), s)

        # --- nose ---
        _circ_o(surface, self.C_NOSE, _mir(snx, s*0.07, d), y+bob+int(s*0.03), max(2, int(s*0.045)), s)

        # --- eye ---
        er = max(4, int(s*0.10))
        _cute_eye(surface, _mir(fcx, s*0.06, d), y+bob-int(s*0.09), er, blink)

        # --- blush ---
        _blush(surface, _mir(fcx, s*0.12, d), y+bob+int(s*0.08), s)

        # --- tiny legs ---
        lw, lh = int(s*0.12), int(s*0.10)
        sw2 = math.sin(self.walk_phase*2)*int(s*0.03) if self.state==self.WALKING else 0
        for i, ox in enumerate([-0.18, 0.0, 0.18]):
            lb = sw2 if i%2==0 else -sw2
            _ec(surface, self.C_BACK, x+int(s*ox), y+int(sh*0.52)+lb+bob, lw, lh)


# ===========================================================================
# SQUIRREL  🐿️
# ===========================================================================

class Squirrel(Animal):
    SPECIES    = "squirrel"
    BASE_SPEED = 65
    SPEED_VARIANCE = 0.35
    PARTICLE_COLORS = [(178, 138, 95), (165, 108, 60), (200, 185, 150)]

    C_BODY  = (178, 138, 95)
    C_BELLY = (215, 188, 148)
    C_TAIL  = (168, 108, 62)
    C_TAIL2 = (198, 145, 92)
    C_EAR   = (158, 118, 75)

    def draw(self, surface, anim_t):
        x, y, s, d = int(self.x), int(self.y), self.size, self.direction
        bob = int(self._bob())
        blink = self._blink()
        tail_wave = math.sin(self.anim_t * 2.0) * int(s * 0.10)

        # --- huge fluffy tail (behind body, drawn first) ---
        tcx = _mir(x, -s*0.24, d)
        tcy = y - int(s*0.18) + bob + tail_wave
        tw, th = int(s*0.56), int(s*0.66)
        _ec_o(surface, self.C_TAIL, tcx, tcy, tw, th, s)
        # inner tail fluff
        _ec(surface, self.C_TAIL2, tcx+int(d*-s*0.04), tcy-int(s*0.04), int(tw*0.65), int(th*0.62))
        # tail tip highlight
        _ec(surface, self.C_BELLY, tcx+int(d*-s*0.06), tcy-int(s*0.12), int(tw*0.35), int(th*0.30))

        # --- body (compact oval) ---
        bw, bh = int(s*0.54), int(s*0.52)
        _ec_o(surface, self.C_BODY, x, y+bob, bw, bh, s)

        # --- belly ---
        _ec(surface, self.C_BELLY, x, y+bob+int(s*0.05), int(bw*0.58), int(bh*0.72))

        # --- head (big, with chubby cheeks) ---
        hx = _mir(x, s*0.20, d)
        hy = y - int(s*0.26) + bob
        hr = int(s*0.26)
        _circ_o(surface, self.C_BODY, hx, hy, hr, s)

        # chubby cheek pouches
        for cx_off in [-0.18, 0.18]:
            _ec(surface, self.C_BODY, hx+int(s*cx_off*d), hy+int(s*0.04), int(s*0.14), int(s*0.12))

        # --- ears ---
        for ox in [-0.12, 0.12]:
            ex = hx + int(s*ox*d)
            ey = hy - hr + int(s*0.02)
            er2 = int(s*0.10)
            _circ_o(surface, self.C_EAR, ex, ey, er2, s)
            _circ(surface, self.C_BELLY, ex, ey+int(er2*0.15), max(2, int(er2*0.52)))

        # --- eyes ---
        er = max(5, int(s*0.12))
        for ox in [-0.09, 0.09]:
            _cute_eye(surface, hx+int(s*ox*d), hy-int(s*0.03), er, blink)

        # --- blush ---
        _blush(surface, hx+int(d*-s*0.16), hy+int(s*0.07), s)
        _blush(surface, hx+int(d* s*0.16), hy+int(s*0.07), s)

        # --- nose ---
        _circ_o(surface, (68, 42, 28), hx+int(d*s*0.08), hy+int(s*0.07), max(2, int(s*0.04)), s)

        # --- paws ---
        sw2 = math.sin(self.walk_phase*2)*int(s*0.05) if self.state==self.WALKING else 0
        for i, ox in enumerate([-0.20, 0.20]):
            lb = sw2 if i==0 else -sw2
            _ec_o(surface, self.C_EAR, x+int(s*ox), y+int(bh*0.52)+lb+bob, int(s*0.13), int(s*0.13), s)


# ===========================================================================
# OTTER  🦦
# ===========================================================================

class Otter(Animal):
    SPECIES    = "otter"
    BASE_SPEED = 55
    SIZE_SCALE = 1.05
    PARTICLE_COLORS = [(125, 85, 55), (192, 158, 125), (215, 195, 168)]

    C_BODY  = (125, 85, 55)
    C_BELLY = (192, 158, 125)
    C_MUZZ  = (175, 145, 115)
    C_NOSE  = (75, 48, 35)

    def draw(self, surface, anim_t):
        x, y, s, d = int(self.x), int(self.y), self.size, self.direction
        bob = int(self._bob())
        blink = self._blink()

        # --- tail ---
        tx = _mir(x, -s*0.40, d)
        _ec_o(surface, self.C_BODY, tx, y+bob+int(s*0.10), int(s*0.22), int(s*0.16), s)

        # --- body (elongated, chubby) ---
        bw, bh = int(s*0.82), int(s*0.46)
        _ec_o(surface, self.C_BODY, x, y+bob, bw, bh, s)

        # --- belly (light patch) ---
        _ec(surface, self.C_BELLY, x, y+bob+int(s*0.05), int(bw*0.58), int(bh*0.78))

        # --- head (round) ---
        hx = _mir(x, s*0.30, d)
        hy = y - int(s*0.16) + bob
        hr = int(s*0.24)
        _circ_o(surface, self.C_BODY, hx, hy, hr, s)

        # --- muzzle ---
        mx = _mir(hx, s*0.18, d)
        my = hy + int(s*0.05)
        _ec_o(surface, self.C_MUZZ, mx, my, int(s*0.24), int(s*0.20), s)

        # --- nose ---
        _circ_o(surface, self.C_NOSE, _mir(mx, s*0.06, d), my-int(s*0.03), max(3, int(s*0.05)), s)

        # --- whiskers ---
        _whiskers(surface, mx, my, s, d)

        # --- eyes ---
        er = max(5, int(s*0.11))
        _cute_eye(surface, _mir(hx, -s*0.05, d), hy-int(s*0.07), er, blink)

        # --- blush ---
        _blush(surface, _mir(hx, -s*0.14, d), hy+int(s*0.05), s)

        # --- ears (small round) ---
        for ox in [-0.12, 0.12]:
            ex = hx + int(s*ox*d)
            _circ_o(surface, self.C_BODY, ex, hy-hr+int(s*0.02), int(s*0.075), s)

        # --- paws ---
        sw2 = math.sin(self.walk_phase*2)*int(s*0.04) if self.state==self.WALKING else 0
        for i, ox in enumerate([-0.28, -0.08, 0.08, 0.28]):
            lb = sw2 if i%2==0 else -sw2
            _ec_o(surface, self.C_BODY, x+int(s*ox), y+int(bh*0.52)+lb+bob, int(s*0.13), int(s*0.11), s)


# ===========================================================================
# PANDA  🐼
# ===========================================================================

class Panda(Animal):
    SPECIES    = "panda"
    BASE_SPEED = 34
    SIZE_SCALE = 1.10
    PARTICLE_COLORS = [(242, 242, 242), (42, 42, 42), (160, 160, 160)]

    C_WHIT