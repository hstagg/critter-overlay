# 🐾 Critter Overlay

Adorable cartoon animals that wander across your screen. Click them to pop them. Invisible when idle.

---

## Quick start

### Run from source

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Launch
python src/main.py
```

### Build a standalone .exe

```bash
# Double-click build.bat
# Or run:
pyinstaller build.spec --noconfirm
# Executable: dist/CritterOverlay.exe
```

---

## Keyboard shortcuts

| Shortcut | Action |
|---|---|
| `Ctrl+Shift+A` | Open / close settings |
| `Ctrl+Shift+P` | Pause / resume spawning |
| `Esc` (in settings) | Close settings |

---

## How it works

- Animals spawn in groups of 5–10 every 15 minutes (configurable).
- A solo perimeter walker also appears every ~15 minutes, circling the screen edges.
- Click any animal to pop it with a particle burst and sound effect.
- When no animals are present the app is **completely invisible** — no icon, no overlay, nothing.
- Settings persist in `%APPDATA%\CritterOverlay\settings.json`.

---

## Animals

| Animal | Default weight | Speed |
|---|---|---|
| 🐱 Kitten | 3× | Medium-fast |
| 🐢 Turtle | 1× | Slow |
| 🦆 Duck | 1× | Medium |
| 🐰 Rabbit | 1× | Fast |
| 🦔 Hedgehog | 1× | Medium-slow |
| 🐿️ Squirrel | 1× | Fast |
| 🦦 Otter | 1× | Medium |
| 🐼 Panda | 1× | Slow-medium |

---

## Settings reference

Open with `Ctrl+Shift+A`. All changes save immediately.

**Animals tab** — toggle species on/off, adjust relative spawn weight.  
**Spawning tab** — set primary spawn frequency, group size, solo spawn toggle and frequency.  
**Visuals tab** — animal size (80–200px), opacity, animation detail.  
**Audio tab** — master toggle, volume, per-animal sounds.  
**System tab** — auto-launch on startup, keyboard shortcut reference.

The **"Spawn now"** button in settings triggers an immediate group spawn for testing.

---

## Troubleshooting

**Global hotkeys not working**  
The `keyboard` library sometimes requires administrator privileges on Windows. Try right-clicking the exe → Run as administrator.

**Animals not appearing transparent**  
The app uses Win32 colour-key transparency. If your desktop is exactly magenta `(255, 0, 255)` this would cause visual conflicts — but that is extraordinarily unlikely.

**High CPU usage**  
Open settings → Visuals → set Animation to "Simple". Also check no other high-CPU processes are competing.

**Settings file corrupted**  
Delete `%APPDATA%\CritterOverlay\settings.json` and restart — defaults will be restored automatically.

---

## Project structure

```
Critter Overlay App/
├── src/
│   ├── main.py             Entry point, hotkeys, single-instance
│   ├── config.py           JSON settings management
│   ├── overlay.py          Pygame transparent window + render loop
│   ├── animals.py          8 animal classes + particle system
│   ├── spawn_manager.py    Spawn timers (primary + solo)
│   ├── settings_window.py  Tkinter settings UI
│   └── sounds.py           Procedural sound generation (numpy)
├── requirements.txt
├── build.spec              PyInstaller config
├── build.bat               One-click build script
└── README.md
```

---

## Technical notes

- **Transparency**: Win32 `SetLayeredWindowAttributes` with colour key `(255, 0, 255)`. Magenta pixels become transparent and click-through automatically. Animal pixels (non-magenta) are visible and clickable.
- **No taskbar entry**: `WS_EX_TOOLWINDOW` extended style.
- **Always on top**: `SetWindowPos(HWND_TOPMOST, ...)`.
- **Sounds**: Generated at runtime using numpy sine-wave synthesis — no audio files bundled.
- **Settings UI**: Tkinter in a daemon thread (dark mode, tabbed layout).
- **Single instance**: Windows named mutex.
