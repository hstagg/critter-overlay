"""
spawn_manager.py — Spawn timing for Critter Overlay App
"""

import random
import time
import math
from typing import Callable

from animals import create_animal, Animal
from config import get_animal_weights

# First spawn fires 30 seconds after launch so users see it's working immediately
FIRST_SPAWN_DELAY = 30.0


class SpawnManager:

    def __init__(self, screen_w: int, screen_h: int, config: dict,
                 on_spawn: Callable[[list], None]):
        self.screen_w = screen_w
        self.screen_h = screen_h
        self.config = config
        self.on_spawn = on_spawn

        now = time.monotonic()
        self._primary_next = now + FIRST_SPAWN_DELAY
        self._solo_next    = now + self._solo_interval()

    # ------------------------------------------------------------------
    # Config helpers
    # ------------------------------------------------------------------

    def _primary_interval(self) -> float:
        minutes = self.config["spawn"].get("primary_interval_min", 5)
        return minutes * 60.0 * random.uniform(0.85, 1.15)

    def _solo_interval(self) -> float:
        minutes = self.config["spawn"].get("solo_interval_min", 10)
        return minutes * 60.0 * random.uniform(0.85, 1.15)

    def _pick_species(self):
        weights = get_animal_weights(self.config)
        if not weights:
            return None
        return random.choices(list(weights.keys()), weights=list(weights.values()), k=1)[0]

    def _animal_size(self) -> int:
        return self.config["visual"].get("animal_size", 120)

    def _random_pos(self):
        margin = 120
        return (
            random.uniform(margin, self.screen_w - margin),
            random.uniform(margin, self.screen_h - margin),
        )

    def _edge_pos(self):
        m = int(self._animal_size() * 0.85)  # matches perimeter walk margin
        edge = random.choice(["top", "bottom", "left", "right"])
        if edge == "top":
            return random.uniform(m, self.screen_w - m), float(m), random.choice([-1, 1])
        elif edge == "bottom":
            return random.uniform(m, self.screen_w - m), float(self.screen_h - m), random.choice([-1, 1])
        elif edge == "left":
            return float(m), random.uniform(m, self.screen_h - m), 1
        else:
            return float(self.screen_w - m), random.uniform(m, self.screen_h - m), -1

    # ------------------------------------------------------------------
    # Tick — call every frame with dt
    # ------------------------------------------------------------------

    def tick(self, dt: float, paused: bool = False) -> None:
        if paused:
            # Freeze the countdown — push targets forward by dt
            self._primary_next += dt
            self._solo_next    += dt
            return

        now = time.monotonic()

        if now >= self._primary_next:
            self._spawn_primary()
            self._primary_next = now + self._primary_interval()

        if self.config["spawn"].get("solo_enabled", True) and now >= self._solo_next:
            self._spawn_solo()
            self._solo_next = now + self._solo_interval()

    def apply_config(self, config: dict) -> None:
        self.config = config

    # ------------------------------------------------------------------
    # Spawn actions
    # ------------------------------------------------------------------

    def _spawn_primary(self) -> None:
        species = self._pick_species()
        if not species:
            return
        count = random.randint(
            self.config["spawn"].get("primary_count_min", 5),
            self.config["spawn"].get("primary_count_max", 10),
        )
        size = self._animal_size()
        animals = [
            create_animal(species, *self._random_pos(), size, self.screen_w, self.screen_h)
            for _ in range(count)
        ]
        self.on_spawn(animals)

    def _spawn_solo(self) -> None:
        species = self._pick_species()
        if not species:
            return
        x, y, direction = self._edge_pos()
        animal = create_animal(species, x, y, self._animal_size(),
                               self.screen_w, self.screen_h,
                               direction=direction, perimeter_walker=True)
        self.on_spawn([animal])

    def force_spawn(self) -> None:
        self._spawn_primary()

    def force_solo(self) -> None:
        self._spawn_solo()
