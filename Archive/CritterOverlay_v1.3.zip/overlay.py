"""
overlay.py — Main pygame transparent overlay window for Critter Overlay App

Technical approach:
  - Full-screen borderless pygame window
  - Win32 SetLayeredWindowAttributes with colour key (255, 0, 255) = magenta
  - Background filled with magenta → appears transparent to user
  - Animal pixels (non-magenta) are visible and capture mouse clicks
  - WS_EX_TOOLWINDOW removes the taskbar entry
  - SetWindowPos HWND_TOPMOST keeps it above everything

Click-through logic:
  - Magenta pixels: Windows automatically passes clicks through to apps below
  - Non-magenta (animal) pixels: clicks land on this window, we handle them
"""

import sys
import ctypes
import ctypes.wintypes
import math
import random
import time

import pygame

from animals import Animal, Particle, create_animal
from spawn_manager import SpawnManager
from sounds import SoundManager
from config import save_config

# ---------------------------------------------------------------------------
# Colour constants
# ---------------------------------------------------------------------------

CHROMA      = (255, 0, 255)   # transparent / click-through background
CHROMA_CREF = 0x00FF00FF      # COLORREF for Windows: 0x00BBGGRR = R=255,G=0,B=255
                               # Wait — COLORREF = R | (G<<8) | (B<<16)
                               # Magenta: 255 | 0<<8 | 255<<16 = 255 + 16711680 = 16711935 = 0xFF00FF
CHROMA_CREF = 255 + (0 << 8) + (255 << 16)   # correct

TARGET_FPS  = 60

# ---------------------------------------------------------------------------
# Win32 setup helpers
# ---------------------------------------------------------------------------

GWL_EXSTYLE       = -20
WS_EX_LAYERED     = 0x00080000
WS_EX_TOOLWINDOW  = 0x00000080   # no taskbar button
WS_EX_TOPMOST     = 0x00000008   # (handled via SetWindowPos)
LWA_COLORKEY      = 0x00000001
HWND_TOPMOST      = ctypes.wintypes.HWND(-1)
SWP_NOMOVE        = 0x0002
SWP_NOSIZE        = 0x0001
SWP_NOACTIVATE    = 0x0010
SWP_SHOWWINDOW    = 0x0040


def _setup_win32_overlay(hwnd: int) -> None:
    user32 = ctypes.windll.user32

    # Add layered + toolwindow styles
    ex = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
    ex |= WS_EX_LAYERED | WS_EX_TOOLWINDOW
    user32.SetWindowLongW(hwnd, GWL_EXSTYLE, ex)

    # Colour key transparency
    user32.SetLayeredWindowAttributes(hwnd, CHROMA_CREF, 0, LWA_COLORKEY)

    # Always on top, no focus steal
    user32.SetWindowPos(
        hwnd, HWND_TOPMOST, 0, 0, 0, 0,
        SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE
    )


# ---------------------------------------------------------------------------
# Pop flash notification (brief text overlay)
# ---------------------------------------------------------------------------

class Notification:
    def __init__(self, text: str, x: int, y: int, color=(255, 230, 80)):
        self.text = text
        self.x = x
        self.y = float(y)
        self.color = color
        self.life = 1.5   # seconds

    def update(self, dt: float) -> bool:
        self.y -= 28 * dt
        self.life -= dt
        return self.life > 0

    def draw(self, surface, font):
        alpha = min(1.0, self.life * 1.5)
        # Fade by blending colour toward background... can't do alpha with
        # chroma key easily, so just draw while alive
        surf = font.render(self.text, True, self.color)
        surface.blit(surf, (int(self.x - surf.get_width() / 2), int(self.y)))


# ---------------------------------------------------------------------------
# Main Overlay class
# ---------------------------------------------------------------------------

class Overlay:

    def __init__(self, config: dict, sound_manager: SoundManager,
                 open_settings_fn, quit_event, on_pause_changed=None):
        self.config = config
        self.sound_manager = sound_manager
        self.open_settings_fn = open_settings_fn
        self.quit_event = quit_event
        self._on_pause_changed = on_pause_changed  # callback → updates tray icon

        self.paused: bool = False  # always start unpaused

        # Animals and particles alive on screen
        self._animals: list[Animal] = []
        self._particles: list[Particle] = []
        self._notifications: list[Notification] = []

        # Settings change detection
        self._config_dirty: bool = False

        # Initialise display
        pygame.init()
        info = pygame.display.Info()
        self.screen_w = info.current_w
        self.screen_h = info.current_h

        # Full-screen borderless window positioned at 0,0
        import os
        os.environ.setdefault("SDL_VIDEO_WINDOW_POS", "0,0")
        self.screen = pygame.display.set_mode(
            (self.screen_w, self.screen_h),
            pygame.NOFRAME | pygame.HWSURFACE | pygame.DOUBLEBUF
        )
        pygame.display.set_caption("CritterOverlay")

        # Win32 overlay magic
        try:
            wm = pygame.display.get_wm_info()
            hwnd = wm.get("window")
            if hwnd:
                _setup_win32_overlay(hwnd)
        except Exception as e:
            print(f"[overlay] Win32 setup warning: {e}")

        # Font for notifications
        pygame.font.init()
        self._font = pygame.font.SysFont("Segoe UI", 18, bold=True)

        # Spawn manager
        self._spawn_manager = SpawnManager(
            self.screen_w, self.screen_h, config,
            on_spawn=self._on_spawn
        )

        self._clock = pygame.time.Clock()

    # ------------------------------------------------------------------
    # Public API (called from main thread or hotkey callbacks)
    # ------------------------------------------------------------------

    def toggle_pause(self) -> None:
        self.paused = not self.paused
        if self._on_pause_changed:
            self._on_pause_changed()

    def apply_new_config(self, new_config: dict) -> None:
        """Called when settings window saves a change."""
        self.config = new_config
        self.paused = new_config["system"].get("paused", False)
        self._spawn_manager.apply_config(new_config)
        self.sound_manager.apply_config(new_config)
        self._config_dirty = True

    def request_quit(self) -> None:
        self.quit_event.set()

    def force_spawn(self) -> None:
        self._spawn_manager.force_spawn()

    def force_solo(self) -> None:
        self._spawn_manager.force_solo()

    # ------------------------------------------------------------------
    # Spawn callback
    # ------------------------------------------------------------------

    def _on_spawn(self, animals: list[Animal]) -> None:
        self._animals.extend(animals)

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    def run(self) -> None:
        prev_time = time.monotonic()

        while not self.quit_event.is_set():
            now = time.monotonic()
            dt = min(now - prev_time, 0.05)   # cap dt to avoid spiral on lag
            prev_time = now

            self._handle_events()
            self._update(dt)
            self._render()
            self._clock.tick(TARGET_FPS)

        self._cleanup()

    # ------------------------------------------------------------------
    # Event handling
    # ------------------------------------------------------------------

    def _handle_events(self) -> None:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.quit_event.set()

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                self._handle_click(event.pos)

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.quit_event.set()

    def _handle_click(self, pos: tuple[int, int]) -> None:
        mx, my = pos
        for animal in list(self._animals):
            if animal.alive and animal.hit_test(mx, my):
                self._pop_animal(animal)
                break  # one click = one pop

    def _pop_animal(self, animal: Animal) -> None:
        animal.alive = False
        self._animals.remove(animal)

        # Spawn particles
        colors = animal.PARTICLE_COLORS
        for _ in range(random.randint(10, 16)):
            color = random.choice(colors)
            p = Particle(animal.x, animal.y, color)
            self._particles.append(p)

        # Play sound
        self.sound_manager.play(animal.SPECIES, self.config)

    # ------------------------------------------------------------------
    # Update
    # ------------------------------------------------------------------

    def _update(self, dt: float) -> None:
        # Tick spawn manager — pass dt so it can freeze countdown while paused
        self._spawn_manager.tick(dt=dt, paused=self.paused)

        # Update animals
        for animal in list(self._animals):
            animal.update(dt, self._animals)

        # Update particles
        self._particles = [p for p in self._particles if p.update(dt)]

        # Update notifications
        self._notifications = [n for n in self._notifications if n.update(dt)]

    # ------------------------------------------------------------------
    # Render
    # ------------------------------------------------------------------

    def _render(self) -> None:
        # Fill background with chroma key (becomes transparent)
        self.screen.fill(CHROMA)

        # Draw all animals
        for animal in self._animals:
            animal.draw(self.screen, animal.anim_t)

        # Draw particles
        for p in self._particles:
            p.draw(self.screen)

        # Draw notifications
        for n in self._notifications:
            n.draw(self.screen, self._font)

        pygame.display.flip()

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def _cleanup(self) -> None:
        pygame.quit()
