"""
main.py — Entry point for Critter Overlay App

System tray icon (bottom-right of taskbar):
  Green paw  = running
  Red paw    = paused

Right-click tray for: Settings | Spawn Now | Pause/Resume | Quit
One keyboard shortcut: Ctrl+Shift+P  — toggle pause from any app

The main settings window is a proper app window (shows in taskbar).
Close it with X to minimise; reopen from the tray icon or taskbar.
"""

import sys
import os
import ctypes
import winreg
import threading
from pathlib import Path

# ---------------------------------------------------------------------------
# Single instance check
# ---------------------------------------------------------------------------

_MUTEX_NAME   = "CritterOverlayMutex_v1"
_mutex_handle = None

def _ensure_single_instance() -> bool:
    global _mutex_handle
    _mutex_handle = ctypes.windll.kernel32.CreateMutexW(None, False, _MUTEX_NAME)
    if ctypes.windll.kernel32.GetLastError() == 183:
        ctypes.windll.user32.MessageBoxW(
            0,
            "Critter Overlay is already running.\n"
            "Find the paw icon in your system tray (bottom-right of taskbar).",
            "Critter Overlay",
            0x40,
        )
        return False
    return True

# ---------------------------------------------------------------------------
# Auto-startup registry
# ---------------------------------------------------------------------------

_REG_KEY  = r"Software\Microsoft\Windows\CurrentVersion\Run"
_REG_NAME = "CritterOverlay"

def _set_autostart(enabled: bool) -> None:
    try:
        if getattr(sys, "frozen", False):
            exe_path = f'"{sys.executable}"'
        else:
            script   = Path(__file__).resolve()
            exe_path = f'"{sys.executable}" "{script}"'
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, _REG_KEY, 0, winreg.KEY_SET_VALUE)
        if enabled:
            winreg.SetValueEx(key, _REG_NAME, 0, winreg.REG_SZ, exe_path)
        else:
            try:
                winreg.DeleteValue(key, _REG_NAME)
            except FileNotFoundError:
                pass
        winreg.CloseKey(key)
    except Exception as e:
        print(f"[startup] Registry error: {e}")

# ---------------------------------------------------------------------------
# Tray icon image (paw print)
# ---------------------------------------------------------------------------

def _make_tray_image(paused: bool = False):
    from PIL import Image, ImageDraw
    size = 64
    img  = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d    = ImageDraw.Draw(img)

    if paused:
        pad = (210, 80,  80,  255)
        toe = (235, 120, 120, 255)
    else:
        pad = (80,  200, 100, 255)
        toe = (120, 230, 140, 255)

    d.ellipse([14, 32, 50, 60], fill=pad)  # main pad
    d.ellipse([ 6, 18, 24, 34], fill=toe)  # left toe
    d.ellipse([22, 10, 42, 28], fill=toe)  # centre toe
    d.ellipse([40, 18, 58, 34], fill=toe)  # right toe
    return img

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    if not _ensure_single_instance():
        sys.exit(0)

    import keyboard
    import pystray
    from config          import load_config, save_config
    from sounds          import SoundManager
    from overlay         import Overlay
    from settings_window import SettingsWindow

    config = load_config()
    _set_autostart(config["system"].get("auto_launch", True))

    quit_event = threading.Event()

    sound_mgr = SoundManager()
    sound_mgr.init(config)

    # Placeholders — assigned before use
    overlay:      Overlay        = None  # type: ignore
    settings_win: SettingsWindow = None  # type: ignore
    tray_icon:    pystray.Icon   = None  # type: ignore

    # ------------------------------------------------------------------
    # Tray refresh helper
    # ------------------------------------------------------------------

    def update_tray() -> None:
        if tray_icon is None:
            return
        try:
            tray_icon.icon  = _make_tray_image(overlay.paused)
            tray_icon.title = (
                "Critter Overlay — Paused  (right-click for options)"
                if overlay.paused else
                "Critter Overlay — Running  (right-click for options)"
            )
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Callbacks
    # ------------------------------------------------------------------

    def on_config_saved(new_config: dict) -> None:
        nonlocal config
        config = new_config
        if overlay:
            overlay.apply_new_config(new_config)
        _set_autostart(new_config["system"].get("auto_launch", True))

    def on_quit() -> None:
        quit_event.set()

    # ------------------------------------------------------------------
    # Build overlay
    # ------------------------------------------------------------------

    overlay = Overlay(
        config           = config,
        sound_manager    = sound_mgr,
        open_settings_fn = lambda: settings_win.open() if settings_win else None,
        quit_event       = quit_event,
        on_pause_changed = update_tray,
    )

    # ------------------------------------------------------------------
    # Build settings window (proper app window, shows in taskbar)
    # -----------------------------------------