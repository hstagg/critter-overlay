"""
settings_window.py — Critter Overlay control window

Proper app-style window (shows in taskbar, minimises on X to tray).
Sidebar navigation, dark theme inspired by Spotify / VS Code.
"""

import base64
import io
import threading
import tkinter as tk
from typing import Callable

from PIL import Image, ImageTk

from config import save_config, reset_to_defaults
try:
    from animal_previews import PREVIEWS as _ANIMAL_PREVIEWS
except ImportError:
    _ANIMAL_PREVIEWS = {}

# Card background as RGB tuple for PIL compositing
_CARD_RGB = (30, 30, 53)   # matches CARD_BG "#1e1e35"
_PREVIEW_SIZE = 96         # display px in the card

# ── Palette ─────────────────────────────────────────────────────────────────

SIDEBAR_BG = "#0f0f1a"   # near-black navy
CONTENT_BG = "#16162a"   # dark navy
CARD_BG    = "#1e1e35"   # card surfaces
CARD_HOV   = "#26263e"   # card hover
ACCENT     = "#c084fc"   # soft violet
ACCENT2    = "#67e8f9"   # cyan highlight
GREEN      = "#4ade80"   # mint — running
RED        = "#f87171"   # coral — paused / danger
AMBER      = "#fbbf24"   # amber — warning
FG         = "#e2e8f0"   # primary text
FG2        = "#94a3b8"   # secondary
FG3        = "#4b5563"   # muted / tertiary
BORDER     = "#1e2040"   # subtle divider
SEL_BG     = "#23234a"   # selected nav item
SLIDER_TR  = "#2d2d55"   # slider trough

FF = "Segoe UI"          # font family

# ── Animal roster ────────────────────────────────────────────────────────────

ANIMALS = [
    ("kitten",   "🐱", "Kitten"),
    ("turtle",   "🐢", "Turtle"),
    ("duck",     "🦆", "Duck"),
    ("rabbit",   "🐰", "Rabbit"),
    ("hedgehog", "🦔", "Hedgehog"),
    ("squirrel", "🐿️", "Squirrel"),
    ("otter",    "🦦", "Otter"),
    ("panda",    "🐼", "Panda"),
]


# ─────────────────────────────────────────────────────────────────────────────

class SettingsWindow:

    def __init__(self,
                 config: dict,
                 on_save: Callable[[dict], None],
                 on_force_spawn: Callable[[], None],
                 on_quit: Callable[[], None],
                 get_paused: Callable[[], bool] = None):
        self._config         = config
        self._on_save        = on_save
        self._on_force_spawn = on_force_spawn
        self._on_quit        = on_quit
        self._get_paused     = get_paused or (lambda: False)
        self._on_toggle_pause: Callable | None = None

        self._root: tk.Tk | None = None
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()

        # Pre-load animal preview images (PIL → ImageTk, kept alive here)
        self._animal_photos: dict[str, ImageTk.PhotoImage] = {}
        self._load_animal_previews()

        self._current_page = "home"
        self._content_frame: tk.Frame | None = None
        self._nav_btns: dict[str, tk.Button] = {}

        # Live-update labels
        self._status_dot: tk.Label | None   = None
        self._status_lbl: tk.Label | None   = None
        self._sidebar_pause_btn: tk.Button | None = None
        self._home_big_lbl: tk.Label | None = None
        self._home_big_sub: tk.Label | None = None
        self._home_big_bg:  str = CARD_BG

    # ── Public API ────────────────────────────────────────────────────────────

    def set_toggle_pause(self, fn: Callable) -> None:
        """Wire in the pause-toggle action after construction."""
        self._on_toggle_pause = fn

    def open(self) -> None:
        with self._lock:
            if self._thread and self._thread.is_alive():
                if self._root:
                    self._root.after(0, self._restore)
                return
            self._thread = threading.Thread(target=self._run, daemon=True)
            self._thread.start()

    def close(self) -> None:
        if self._root:
            try:
                self._root.after(0, self._root.destroy)
            except Exception:
                pass

    def update_config(self, config: dict) -> None:
        self._config = config

    # ── Internal ──────────────────────────────────────────────────────────────

    def _restore(self) -> None:
        self._root.deiconify()
        self._root.lift()
        self._root.focus_force()

    def _run(self) -> None:
        self._root = tk.Tk()
        self._build_window()
        self._poll_status()
        self._root.mainloop()
        self._root = None

    # ── Window skeleton ───────────────────────────────────────────────────────

    def _build_window(self) -> None:
        root = self._root
        root.title("Critter Overlay")
        root.configure(bg=SIDEBAR_BG)
        root.resizable(True, True)
        root.minsize(700, 500)

        # X button → minimise to tray, don't quit
        root.protocol("WM_DELETE_WINDOW", lambda: root.withdraw())

        w, h = 800, 580
        sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
        root.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")

        # Two-column layout
        sidebar = tk.Frame(root, bg=SIDEBAR_BG, width=190)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        divider = tk.Frame(root, bg=BORDER, width=1)
        divider.pack(side="left", fill="y")

        content_wrap = tk.Frame(root, bg=CONTENT_BG)
        content_wrap.pack(side="left", fill="both", expand=True)

        self._content_frame = content_wrap
        self._build_sidebar(sidebar)
        self._show_page("home")

    # ── Sidebar ───────────────────────────────────────────────────────────────

    def _build_sidebar(self, parent: tk.Frame) -> None:

        # ── Branding ──
        brand = tk.Frame(parent, bg=SIDEBAR_BG)
        brand.pack(fill="x", pady=(28, 20), padx=20)

        tk.Label(brand, text="🐾", font=(FF, 30), bg=SIDEBAR_BG).pack(anchor="w")
        tk.Label(brand, text="Critter Overlay", font=(FF, 13, "bold"),
                 bg=SIDEBAR_BG, fg=FG).pack(anchor="w", pady=(4, 0))
        tk.Label(brand, text="v1.0", font=(FF, 8),
                 bg=SIDEBAR_BG, fg=FG3).pack(anchor="w")

        # ── Status pill ──
        pill = tk.Frame(parent, bg=SIDEBAR_BG)
        pill.pack(fill="x", padx=20, pady=(0, 18))

        self._status_dot = tk.Label(pill, text="●", font=(FF, 11),
                                    bg=SIDEBAR_BG, fg=GREEN)
        self._status_dot.pack(side="left")
        self._status_lbl = tk.Label(pill, text="Running", font=(FF, 9),
                                    bg=SIDEBAR_BG, fg=GREEN)
        self._status_lbl.pack(side="left", padx=(5, 0))

        # ── Nav separator ──
        tk.Frame(parent, bg=BORDER, height=1).pack(fill="x", padx=16, pady=(0, 10))

        # ── Nav items ──
        nav = [
            ("home",     "⌂",  "Home"),
            ("animals",  "🐾", "Animals"),
            ("spawning", "⏱",  "Spawning"),
            ("audio",    "🔊", "Audio"),
            ("system",   "⚙",  "System"),
        ]
        for page_id, icon, label in nav:
            btn = tk.Button(
                parent,
                text=f"  {icon}   {label}",
                anchor="w",
                command=lambda p=page_id: self._show_page(p),
                bg=SIDEBAR_BG, fg=FG2,
                activebackground=SEL_BG, activeforeground=FG,
                relief="flat", font=(FF, 10),
                cursor="hand2", pady=11, padx=12,
            )
            btn.pack(fill="x", padx=8, pady=1)
            self._nav_btns[page_id] = btn

        # ── Bottom actions ──
        tk.Frame(parent, bg=BORDER, height=1).pack(fill="x", padx=16, pady=14)

        spawn_btn = tk.Button(
            parent,
            text="💥  Spawn Now",
            command=self._on_force_spawn,
            bg="#1a0f35", fg=ACCENT,
            activebackground="#23154a", activeforeground=ACCENT,
            relief="flat", font=(FF, 9, "bold"),
            cursor="hand2", pady=9,
        )
        spawn_btn.pack(fill="x", padx=12, pady=(0, 6))

        self._sidebar_pause_btn = tk.Button(
            parent,
            text="⏸  Pause",
            command=self._toggle_pause,
            bg="#120f0f", fg=FG2,
            activebackground="#1e1515", activeforeground=RED,
            relief="flat", font=(FF, 9, "bold"),
            cursor="hand2", pady=9,
        )
        self._sidebar_pause_btn.pack(fill="x", padx=12, pady=(0, 16))

    # ── Status polling ────────────────────────────────────────────────────────

    def _poll_status(self) -> None:
        if self._root is None:
            return
        paused = self._get_paused()
        self._apply_status(paused)
        self._root.after(700, self._poll_status)

    def _apply_status(self, paused: bool) -> None:
        dot_col  = RED   if paused else GREEN
        dot_text = "⏸"  if paused else "●"
        lbl_text = "Paused"  if paused else "Running"
        btn_text = "▶  Resume" if paused else "⏸  Pause"
        btn_fg   = GREEN if paused else FG2

        if self._status_dot:
            try:
                self._status_dot.configure(text=dot_text, fg=dot_col)
            except tk.TclError:
                pass
        if self._status_lbl:
            try:
                self._status_lbl.configure(text=lbl_text, fg=dot_col)
            except tk.TclError:
                pass
        if self._sidebar_pause_btn:
            try:
                self._sidebar_pause_btn.configure(text=btn_text, fg=btn_fg)
            except tk.TclError:
                pass

        # Home-page live labels
        if self._current_page == "home":
            self._refresh_home_status(paused)

    def _refresh_home_status(self, paused: bool) -> None:
        if self._home_big_lbl is None:
            return
        try:
            if paused:
                bg   = "#1f0f0f"
                fg   = RED
                text = "⏸  PAUSED"
                sub  = "Animals are frozen — click Resume to continue."
            else:
                bg   = "#0f1f12"
                fg   = GREEN
                text = "●  RUNNING"
                sub  = "Animals are roaming freely across your screen."

            self._home_big_lbl.configure(text=text, fg=fg, bg=bg)
            self._home_big_sub.configure(text=sub, bg=bg)
            self._home_big_lbl.master.configure(bg=bg)
        except tk.TclError:
            pass

    # ── Page routing ──────────────────────────────────────────────────────────

    def _show_page(self, page_id: str) -> None:
        self._current_page = page_id

        for pid, btn in self._nav_btns.items():
            if pid == page_id:
                btn.configure(bg=SEL_BG, fg=FG, font=(FF, 10, "bold"))
            else:
                btn.configure(bg=SIDEBAR_BG, fg=FG2, font=(FF, 10))

        for w in self._content_frame.winfo_children():
            w.destroy()

        # Reset home live labels
        self._home_big_lbl = None
        self._home_big_sub = None

        {
            "home":     self._page_home,
            "animals":  self._page_animals,
            "spawning": self._page_spawning,
            "audio":    self._page_audio,
            "system":   self._page_system,
        }.get(page_id, self._page_home)(self._content_frame)

    # ── Page: Home ────────────────────────────────────────────────────────────

    def _page_home(self, parent: tk.Frame) -> None:
        scroll_canvas, inner = self._scrollable(parent)

        paused = self._get_paused()

        # ── Big status card ──
        status_bg = "#0f1f12" if not paused else "#1f0f0f"
        status_card = tk.Frame(inner, bg=status_bg, padx=24, pady=22)
        status_card.pack(fill="x", pady=(0, 16))

        self._home_big_lbl = tk.Label(
            status_card,
            text="●  RUNNING" if not paused else "⏸  PAUSED",
            font=(FF, 26, "bold"),
            bg=status_bg,
            fg=GREEN if not paused else RED,
        )
        self._home_big_lbl.pack(anchor="w")

        self._home_big_sub = tk.Label(
            status_card,
            text=("Animals are roaming freely across your screen."
                  if not paused else "Animals are frozen — click Resume to continue."),
            font=(FF, 10),
            bg=status_bg,
            fg=FG2,
        )
        self._home_big_sub.pack(anchor="w", pady=(5, 0))

        # ── Quick-action pair ──
        actions = tk.Frame(inner, bg=CONTENT_BG)
        actions.pack(fill="x", pady=(0, 20))
        actions.grid_columnconfigure(0, weight=1)
        actions.grid_columnconfigure(1, weight=1)

        self._action_card(
            actions, row=0, col=0, padright=8,
            icon="💥", title="Spawn Now",
            desc="Send a wave of critters onto the screen",
            color=ACCENT,
            command=self._on_force_spawn,
        )
        self._action_card(
            actions, row=0, col=1, padright=0,
            icon="▶" if paused else "⏸",
            title="Resume" if paused else "Pause",
            desc="Freeze or unfreeze all animal activity",
            color=GREEN if paused else RED,
            command=self._toggle_pause,
        )

        # ── Stat trio ──
        stats = tk.Frame(inner, bg=CONTENT_BG)
        stats.pack(fill="x", pady=(0, 24))
        stats.grid_columnconfigure(0, weight=1)
        stats.grid_columnconfigure(1, weight=1)
        stats.grid_columnconfigure(2, weight=1)

        spawn_min   = self._config["spawn"].get("primary_interval_min", 5)
        cnt_min     = self._config["spawn"].get("primary_count_min", 5)
        cnt_max     = self._config["spawn"].get("primary_count_max", 10)
        enabled_n   = sum(1 for s in self._config["animals"].values()
                          if s.get("enabled", True))

        self._stat_card(stats, col=0, pad=8, icon="⏱",
                        value=f"{spawn_min} min", label="Spawn interval")
        self._stat_card(stats, col=1, pad=8, icon="🐾",
                        value=f"{cnt_min}–{cnt_max}", label="Per-spawn count")
        self._stat_card(stats, col=2, pad=0, icon="✓",
                        value=f"{enabled_n} / 8", label="Species active")

        # ── Tip bar ──
        tip = tk.Frame(inner, bg=CARD_BG, padx=16, pady=10)