@echo off
setlocal enabledelayedexpansion
title Critter Overlay

REM Refresh PATH from registry so newly-installed Python is visible
powershell -NoProfile -Command "[Environment]::GetEnvironmentVariable('PATH','User')" > "%TEMP%\critter_upath.tmp" 2>nul
for /f "usebackq delims=" %%P in ("%TEMP%\critter_upath.tmp") do set "PATH=!PATH!;%%P"
del "%TEMP%\critter_upath.tmp" >nul 2>&1

powershell -NoProfile -Command "[Environment]::GetEnvironmentVariable('PATH','Machine')" > "%TEMP%\critter_mpath.tmp" 2>nul
for /f "usebackq delims=" %%P in ("%TEMP%\critter_mpath.tmp") do set "PATH=!PATH!;%%P"
del "%TEMP%\critter_mpath.tmp" >nul 2>&1

REM ----- Find Python (linear, no subroutines) -----
set "PYTHON_EXE="

for /f "tokens=* delims=" %%P in ('where python 2^>nul') do (
    if "!PYTHON_EXE!"=="" (
        "%%P" --version >nul 2>&1
        if not errorlevel 1 set "PYTHON_EXE=%%P"
    )
)

if not defined PYTHON_EXE (
    for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do (
        if "!PYTHON_EXE!"=="" if exist "%%D\python.exe" set "PYTHON_EXE=%%D\python.exe"
    )
)

if not defined PYTHON_EXE (
    for /d %%D in ("C:\Program Files\Python3*") do (
        if "!PYTHON_EXE!"=="" if exist "%%D\python.exe" set "PYTHON_EXE=%%D\python.exe"
    )
)

if not defined PYTHON_EXE (
    for /d %%D in ("C:\Python3*") do (
        if "!PYTHON_EXE!"=="" if exist "%%D\python.exe" set "PYTHON_EXE=%%D\python.exe"
    )
)

if not defined PYTHON_EXE (
    echo.
    echo  Python was not found on this computer.
    echo.
    echo  Run  pythoninstall.bat  first (it is in this folder),
    echo  then run  setup.bat,  then try run.bat again.
    echo.
    pause
    exit /b 1
)

REM Derive pythonw.exe
set "PYTHONW_EXE="
for %%F in ("%PYTHON_EXE%") do set "PYTHONW_EXE=%%~dpFpythonw.exe"
if not exist "%PYTHONW_EXE%" set "PYTHONW_EXE=%PYTHON_EXE%"

REM Check packages
"%PYTHON_EXE%" -c "import pygame, numpy, keyboard" >nul 2>&1
if errorlevel 1 (
    echo Packages missing. Running setup...
    call "%~dp0setup.bat"
    exit /b
)

start "" "%PYTHONW_EXE%" "%~dp0src\main.py"
exit
