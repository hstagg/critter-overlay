@echo off
setlocal enabledelayedexpansion
title Critter Overlay - Setup
color 0A

echo.
echo  =============================================
echo    CRITTER OVERLAY  ^|  First Time Setup
echo  =============================================
echo.

REM -------------------------------------------------------
REM Refresh PATH from registry so newly-installed Python
REM is visible even without restarting Explorer
REM -------------------------------------------------------
powershell -NoProfile -Command "[Environment]::GetEnvironmentVariable('PATH','User')" > "%TEMP%\critter_upath.tmp" 2>nul
for /f "usebackq delims=" %%P in ("%TEMP%\critter_upath.tmp") do set "PATH=!PATH!;%%P"
del "%TEMP%\critter_upath.tmp" >nul 2>&1

powershell -NoProfile -Command "[Environment]::GetEnvironmentVariable('PATH','Machine')" > "%TEMP%\critter_mpath.tmp" 2>nul
for /f "usebackq delims=" %%P in ("%TEMP%\critter_mpath.tmp") do set "PATH=!PATH!;%%P"
del "%TEMP%\critter_mpath.tmp" >nul 2>&1

REM -------------------------------------------------------
REM Find Python
REM -------------------------------------------------------
call :find_python

if not defined PYTHON_EXE (
    echo  [!] Python was not detected on this computer.
    echo.
    echo  To install it automatically, run:
    echo.
    echo      pythoninstall.bat
    echo.
    echo  That file is included in this folder.
    echo  Once Python is installed, run setup.bat again.
    echo.
    pause
    exit /b 1
)

echo  [OK] Python found: %PYTHON_EXE%
echo.

REM -------------------------------------------------------
REM Check version is 3.8+
REM -------------------------------------------------------
"%PYTHON_EXE%" -c "import sys; exit(0 if sys.version_info >= (3,8) else 1)" >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python 3.8 or newer is required.
    echo  Run pythoninstall.bat to install a fresh copy.
    echo.
    pause
    exit /b 1
)

echo  [OK] Python version OK.
echo.
echo  Installing required packages (this may take a minute)...
echo.

REM -------------------------------------------------------
REM Install packages
REM -------------------------------------------------------
"%PYTHON_EXE%" -m pip install --upgrade pip --quiet --no-warn-script-location
"%PYTHON_EXE%" -m pip install pygame numpy keyboard pystray Pillow --quiet --no-warn-script-location

if errorlevel 1 (
    echo.
    echo  [ERROR] Package installation failed.
    echo  Try right-clicking setup.bat and choosing "Run as administrator".
    echo.
    pause
    exit /b 1
)

echo  [OK] All packages installed.
echo.

REM -------------------------------------------------------
REM Optional desktop shortcut
REM -------------------------------------------------------
set "HERE=%~dp0"

echo  Would you like a shortcut on your Desktop?
echo  Press Y for yes, or wait 10 seconds to skip.
echo.
choice /c YN /n /t 10 /d N
if errorlevel 2 goto :skip_shortcut
if errorlevel 1 (
    set "SHORTCUT=%USERPROFILE%\Desktop\Critter Overlay.bat"
    (
        echo @echo off
        echo start "" "!PYTHONW_EXE!" "!HERE!src\main.py"
    ) > "!SHORTCUT!"
    echo  [OK] Desktop shortcut created.
    echo.
)

:skip_shortcut
echo.
echo  =============================================
echo    All done!  Starting Critter Overlay now...
echo  =============================================
echo.
echo  Animals will appear on your screen periodically.
echo  Open settings with:  Ctrl + Shift + A
echo  Pause the app with:  Ctrl + Shift + P
echo.
echo  You can close this window.
echo.
timeout /t 3 /nobreak >nul

start "" "%PYTHONW_EXE%" "%~dp0src\main.py"
exit


REM ===================================================================
REM :find_python
REM Searches PATH, then scans common install locations.
REM Sets PYTHON_EXE and PYTHONW_EXE
REM ===================================================================
:find_python
set "PYTHON_EXE="
set "PYTHONW_EXE="

REM 1. Check PATH via where
for /f "tokens=* delims=" %%P in ('where python 2^>nul') do (
    if "!PYTHON_EXE!"=="" (
        "%%P" --version >nul 2>&1
        if not errorlevel 1 set "PYTHON_EXE=%%P"
    )
)
if defined PYTHON_EXE goto :derive_pythonw

REM 2. User install
for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do (
    if "!PYTHON_EXE!"=="" (
        if exist "%%D\python.exe" set "PYTHON_EXE=%%D\python.exe"
    )
)
if defined PYTHON_EXE goto :derive_pythonw

REM 3. System install
for /d %%D in ("C:\Program Files\Python3*") do (
    if "!PYTHON_EXE!"=="" (
        if exist "%%D\python.exe" set "PYTHON_EXE=%%D\python.exe"
    )
)
if defined PYTHON_EXE goto :derive_pythonw

REM 4. Old-style
for /d %%D in ("C:\Python3*") do (
    if "!PYTHON_EXE!"=="" (
        if exist "%%D\python.exe" set "PYTHON_EXE=%%D\python.exe"
    )
)
if defined PYTHON_EXE goto :derive_pythonw

goto :eof

:derive_pythonw
for %%F in ("!PYTHON_EXE!") do set "PYTHONW_EXE=%%~dpFpythonw.exe"
if not exist "!PYTHONW_EXE!" set "PYTHONW_EXE=!PYTHON_EXE!"
goto :eof
