@echo off
setlocal enabledelayedexpansion
title Critter Overlay

REM -------------------------------------------------------
REM Find Python (same logic as setup.bat)
REM -------------------------------------------------------
call :find_python

if not defined PYTHON_EXE (
    echo Python not detected. Please run setup.bat first.
    pause
    exit /b 1
)

REM Check packages are installed
"%PYTHON_EXE%" -c "import pygame, numpy, keyboard" >nul 2>&1
if errorlevel 1 (
    echo Packages missing. Running setup...
    call "%~dp0setup.