@echo off
setlocal enabledelayedexpansion
title Critter Overlay - Setup
color 0A

echo.
echo  =============================================
echo    CRITTER OVERLAY  ^|  First Time Setup
echo  =============================================
echo.

REM -------------------------------------------------------
REM Find Python
REM -------------------------------------------------------
call :find_python

if not defined PYTHON_EXE (
    echo  [!] Python was not detected on this computer.
    echo.
    echo  To install it automatically, run:
    echo.
    echo      pythoninstall.bat
    echo.
    echo  That file is included in this folder.
    echo  Once Python is installed, run setup.bat again.
    echo.
    pause
    exit /b 1
)

echo  [OK] Python found: %PYTHON_EXE%
echo.

REM -------------------------------------------------------
REM Check version is 3.8+
REM -------------------------------------------------------
"%PYTHON_EXE%" -c "import sys; exit(0 if sys.version_info >= (3,8) else 1)" >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python 3.8 or newer is required.
    echo  Run pythoninstall.bat to install a fresh copy.
    echo.
    pause
    exit /b 1
)

echo  [OK] Python version OK.
echo.
echo  Installing required packages (this may take a minute)...
echo.

REM -------------------------------------------------------
REM Install packages
REM -------------------------------------------------------
"%PYTHON_EXE%" -m pip install --upgrade pip --quiet --no-warn-script-location
"%PYTHON_EXE%" -m pip install pygame numpy keyboard pystray Pillow --quiet --no-warn-script-location

if errorlevel 1 (
    echo.
    echo  [ERROR] Package installation failed.
    echo  Try right-clicking setup.bat and choosing "Run as administrator".
    echo.
    pause
    exit /b 1
)

echo  [OK] All packages installed.
echo.

REM -------------------------------------------------------
REM Optional desktop shortcut
REM -------------------------------------------------------
set "HERE=%~dp0"

echo  Would you like a shortcut on your Desktop?
echo  Press Y for yes, or wait 10 seconds to skip.
echo.
choice /c YN /n /t 10 /d N
if errorlevel 2 goto :skip_shortcut
if errorlevel 1 (
    set "SHORTCUT=%USERPROFILE%\Desktop\Critter Overlay.bat"
    (
        echo @echo off
        echo start "" "!PYTHONW_EXE!" "!HERE!src\main.py"
    ) > "!SHORTCUT!"
    echo  [OK] Desktop shortcut created.
    echo.
)

:skip_shortcut
echo.
echo  =============================================
echo    All done!  Starting Critter Overlay now...
echo  =============================================
echo.
echo  Animals will appear on your screen periodically.
echo  Open settings with:  Ctrl + Shift + A
echo  Pause the app with:  Ctrl + Shift + P
echo.
echo  You can close this window.
echo.
timeout /t 3 /nobreak >nul

start "" "%PYTHONW_EXE%" "%~dp0src\main.py"
exit


REM ===================================================================
REM :find_python
REM Searches PATH, then scans common install locations using wildcards.
REM Sets PYTHON_EXE and PYTHONW_EXE — no version numbers hardcoded.
REM ===================================================================
:find_python
set "PYTHON_EXE="
set "PYTHONW_EXE="

REM 1. Check PATH via 'where'
for /f "tokens=* delims=" %%P in 